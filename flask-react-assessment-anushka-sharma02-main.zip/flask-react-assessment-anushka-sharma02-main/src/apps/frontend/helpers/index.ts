export * as Config from 'frontend/helpers/config';
