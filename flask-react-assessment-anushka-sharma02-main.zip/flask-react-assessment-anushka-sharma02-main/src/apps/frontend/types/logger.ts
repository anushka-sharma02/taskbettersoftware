export interface DatadogUser {
  [key: string]: string;
  email: string;
  id: string;
  name: string;
}
