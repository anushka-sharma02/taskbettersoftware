from datetime import datetime

class CommentModel:
    def __init__(self, task_id: str, content: str):
        self.task_id = task_id
        self.content = content
        self.created_at = datetime.utcnow()
        self.active = True  # for soft delete

    def to_bson(self):
        return {
            "task_id": self.task_id,
            "content": self.content,
            "created_at": self.created_at,
            "active": True
        }
