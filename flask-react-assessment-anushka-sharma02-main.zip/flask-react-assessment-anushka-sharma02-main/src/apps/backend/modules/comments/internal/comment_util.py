from modules.comment.types import Comment

class CommentUtil:
    @staticmethod
    def convert_comment_bson_to_comment(bson_doc) -> Comment:
        return Comment(
            id=str(bson_doc["_id"]),
            task_id=bson_doc["task_id"],
            content=bson_doc["content"],
            created_at=bson_doc.get("created_at")
        )
