from bson.objectid import ObjectId
from modules.comment.internal.store.comment_repository import CommentRepository
from modules.comment.types import Comment
from modules.comment.internal.comment_util import CommentUtil
from modules.comment.errors import CommentNotFoundError

class CommentReader:
    @staticmethod
    def get_comment(comment_id: str) -> Comment:
        comment_bson = CommentRepository.collection().find_one({"_id": ObjectId(comment_id), "active": True})
        if comment_bson is None:
            raise CommentNotFoundError(comment_id)
        return CommentUtil.convert_comment_bson_to_comment(comment_bson)

    @staticmethod
    def get_comments_by_task(task_id: str) -> list[Comment]:
        comments_bson = list(CommentRepository.collection().find({"task_id": task_id, "active": True}))
        return [CommentUtil.convert_comment_bson_to_comment(c) for c in comments_bson]
