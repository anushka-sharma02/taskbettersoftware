from modules.application.common.mongo_repository import MongoRepository

class CommentRepository(MongoRepository):
    @staticmethod
    def collection():
        return MongoRepository.get_collection("comments")
