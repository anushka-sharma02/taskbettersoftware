from modules.application.common.types import PaginationParams

# Default pagination parameters
DEFAULT_PAGINATION_PARAMS = PaginationParams(page=1, size=10, offset=0)
