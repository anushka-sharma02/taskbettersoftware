import json
import pytest
from server import app


@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client


def test_create_comment(client):
    # Replace with a valid account_id and task_id in your DB
    account_id = "1"
    task_id = "1"

    response = client.post(
        f"/accounts/{account_id}/tasks/{task_id}/comments",
        data=json.dumps({"text": "This is a test comment"}),
        content_type="application/json"
    )

    assert response.status_code == 201
    data = response.get_json()
    assert "text" in data
    assert data["text"] == "This is a test comment"


def test_get_comments(client):
    account_id = "1"
    task_id = "1"

    response = client.get(f"/accounts/{account_id}/tasks/{task_id}/comments")
    assert response.status_code == 200
    data = response.get_json()
    assert isinstance(data["items"], list)


def test_update_comment(client):
    account_id = "1"
    task_id = "1"
    comment_id = "1"  # Update with real id from DB

    response = client.patch(
        f"/accounts/{account_id}/tasks/{task_id}/comments/{comment_id}",
        data=json.dumps({"text": "Updated text"}),
        content_type="application/json"
    )
    assert response.status_code in (200, 404)  # 404 if comment not found


def test_delete_comment(client):
    account_id = "1"
    task_id = "1"
    comment_id = "1"  # Update with real id

    response = client.delete(
        f"/accounts/{account_id}/tasks/{task_id}/comments/{comment_id}"
    )
    assert response.status_code in (204, 404)
